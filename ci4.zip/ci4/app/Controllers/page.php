<?php

namespace App\Controllers;

class Page extends BaseController
{
    // Method index untuk menangani rute utama (/)
    public function index()
    {
        return view('about', [
            'title'   => 'Halaman Home',
            'content' => 'Selamat datang di halaman utama. Ini adalah tampilan Home dengan layout sederhana.'
        ]);
    }

    public function about()
    {
        return view('about', [
            'title'   => 'Halaman About',
            'content' => 'Ini adalah halaman About yang menjelaskan tentang isi halaman ini.'
        ]);
    }

    public function contact()
    {
        // Pastikan Anda sudah membuat file app/Views/contact.php
        return view('contact', [
            'title'   => 'Halaman Contact',
            'content' => 'Ini adalah halaman Contact.'
        ]);
    }

    public function faqs()
    {
        // Pastikan Anda sudah membuat file app/Views/faqs.php
        return view('faqs', [
            'title'   => 'Halaman FAQ',
            'content' => 'Ini adalah halaman Frequently Asked Questions.'
        ]);
    }

    public function tos()
    {
        // Pastikan Anda sudah membuat file app/Views/tos.php
        return view('tos', [
            'title'   => 'Term of Services',
            'content' => 'Ini adalah halaman Term of Services.'
        ]);
    }
}