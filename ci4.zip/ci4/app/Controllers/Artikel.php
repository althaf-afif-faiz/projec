<?php

namespace App\Controllers;

use App\Models\ArtikelModel;

class Artikel extends BaseController
{
    public function index()
    {
        $model = new ArtikelModel();

        $data = [
            'title' => 'Daftar Artikel',
            'artikel' => $model->findAll()
        ];

        return view('artikel/index', $data);
    }
}