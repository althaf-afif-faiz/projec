<?= $this->include('template/header'); ?>

<h1><?= $title; ?></h1>
<hr>

<?php if ($artikel): ?>
    <?php foreach ($artikel as $row): ?>

        <article>
            <h2><?= $row['judul']; ?></h2>

            <p><?= substr($row['isi'], 0, 200); ?></p>
        </article>

        <hr>

    <?php endforeach; ?>

<?php else: ?>

    <h2>Belum ada artikel</h2>

<?php endif; ?>

<?= $this->include('template/footer'); ?>